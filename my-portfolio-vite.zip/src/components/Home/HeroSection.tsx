import React from "react";
import { motion } from "framer-motion";
import { FaGithub, FaLinkedin, FaTwitter } from "react-icons/fa";

const HeroSection = () => {
  return (
    <motion.section
      initial={{ opacity: 0, y: -30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-6 text-center md:text-left"
    >
      <h1 className="text-4xl md:text-6xl font-bold leading-tight text-gray-900 dark:text-white">
        Hello, I’m Norbert
      </h1>

      <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300">
        Full-Stack Developer | Cloud Enthusiast | Lifelong Learner
      </p>

      <div className="flex justify-center md:justify-start gap-4 text-2xl text-gray-600 dark:text-gray-300">
        <a href="https://twitter.com/yourhandle" target="_blank" rel="noopener noreferrer">
          <FaTwitter />
        </a>
        <a href="https://linkedin.com/in/yourhandle" target="_blank" rel="noopener noreferrer">
          <FaLinkedin />
        </a>
        <a href="https://github.com/nrbrt02" target="_blank" rel="noopener noreferrer">
          <FaGithub />
        </a>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-center md:justify-start mt-6">
        <a
          href="/cv.pdf"
          download
          className="inline-block px-6 py-2 bg-pink-600 hover:bg-pink-700 text-white font-semibold rounded-md shadow transition-all"
        >
          Download CV
        </a>

        <a
          href="/resume.pdf"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block px-6 py-2 border border-pink-600 text-pink-600 hover:bg-pink-600 hover:text-white font-semibold rounded-md transition-all"
        >
          View Resume
        </a>
      </div>
    </motion.section>
  );
};

export default HeroSection;

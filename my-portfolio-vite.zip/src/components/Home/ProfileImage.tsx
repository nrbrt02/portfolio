const ProfileImage = () => {
  return (
    <div className="relative w-full md:w-1/2">
      <img
        src="https://plus.unsplash.com/premium_photo-1673866484792-c5a36a6c025e?q=80&w=687&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" // Add your profile photo in public folder
        alt="Norbert"
        className="object-cover w-full h-auto rounded-md shadow-lg"
      />
    </div>
  );
};

export default ProfileImage;
